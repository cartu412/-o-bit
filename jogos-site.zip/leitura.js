function verificar(resposta) {
  const resultado = document.getElementById('resultado');
  if (resposta === 'banana') {
    resultado.textContent = '✅ Correto!';
    resultado.style.color = 'green';
  } else {
    resultado.textContent = '❌ Tente de novo!';
    resultado.style.color = 'red';
  }
}