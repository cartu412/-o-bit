const imagens = ['🍎', '🍌', '🍇', '🍓', '🍎', '🍌', '🍇', '🍓'];
let embaralhado = imagens.sort(() => 0.5 - Math.random());
let primeiro = null, segundo = null;
let bloqueado = false;

const tabuleiro = document.getElementById('tabuleiro');
tabuleiro.style.display = 'grid';
tabuleiro.style.gridTemplateColumns = 'repeat(4, 80px)';
tabuleiro.style.gap = '10px';
tabuleiro.style.justifyContent = 'center';

embaralhado.forEach((emoji, i) => {
  const carta = document.createElement('button');
  carta.textContent = '❓';
  carta.style.fontSize = '30px';
  carta.style.width = '80px';
  carta.style.height = '80px';
  carta.dataset.index = i;
  tabuleiro.appendChild(carta);

  carta.addEventListener('click', () => {
    if (bloqueado || carta.textContent !== '❓') return;
    carta.textContent = emoji;

    if (!primeiro) {
      primeiro = { carta, emoji };
    } else {
      segundo = { carta, emoji };
      bloqueado = true;
      setTimeout(() => {
        if (primeiro.emoji !== segundo.emoji) {
          primeiro.carta.textContent = '❓';
          segundo.carta.textContent = '❓';
        }
        primeiro = segundo = null;
        bloqueado = false;
      }, 800);
    }
  });
});