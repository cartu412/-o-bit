function verificar() {
  const valor = document.getElementById('resposta').value;
  const resultado = document.getElementById('resultado');
  if (valor === '8') {
    resultado.textContent = '✅ Certo!';
    resultado.style.color = 'green';
  } else {
    resultado.textContent = '❌ Errado, tente 2 a 2!';
    resultado.style.color = 'red';
  }
}